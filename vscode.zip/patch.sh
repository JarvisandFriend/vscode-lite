#!/usr/bin/env bash
set -e

mkdir -p "$(dirname src/styles/style.css)"
cat > src/styles/style.css << 'CLAUDE_EOF_MARKER_9f3a'
/* ==========================================================================
   VS CODE LITE - ENTERPRISE WORKBENCH & MOBILE RESPONSIVE STYLESHEET
   ========================================================================== */

:root {
  /* Default: Obsidian Aurora (Bespoke Rebranded Studio Palette) */
  --bg-app: #0d1117;
  --bg-titlebar: #0d1117;
  --bg-activitybar: #090d14;
  --bg-sidebar: #0e131d;
  --bg-sidebar-header: #0e131d;
  --bg-editor: #111622;
  --bg-breadcrumbs: #111622;
  --bg-tab-active: #111622;
  --bg-tab-inactive: #090d14;
  --bg-tab-hover: #161c2b;
  --bg-panel: #0c1018;
  --bg-terminal: #0c1018;
  --bg-statusbar: #080c14;
  --bg-input: #151b27;
  --bg-input-focus: #1c2436;
  --bg-hover: #1a2333;
  --bg-selected: #1e2e4a;
  --bg-selected-inactive: #162033;
  --bg-notification: #131924;
  --bg-touchbar: #0d121c;

  --border-color: #1c2436;
  --border-subtle: #141b27;
  --border-input: #243048;
  --border-focus: #6366f1;

  --accent-color: #6366f1;
  --accent-hover: #818cf8;
  --accent-green: #10b981;
  --accent-green-hover: #34d399;
  --accent-blue: #38bdf8;
  --badge-bg: #4f46e5;

  --text-main: #e8e8e8;
  --text-muted: #7888a0;
  --text-bright: #f8fafc;
  --text-dim: #526078;

  --remote-bg: #4f46e5;
  --remote-fg: #ffffff;

  --font-ui: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  --font-code: "Cascadia Code", "Fira Code", Consolas, "Courier New", monospace;

  --titlebar-height: 32px;
  --statusbar-height: 24px;
  --activitybar-width: 48px;
  --sidebar-width: 260px;
}

/* Light Modern Theme */
body.theme-light-modern {
  --bg-app: #f8f8f8;
  --bg-titlebar: #f8f8f8;
  --bg-activitybar: #f8f8f8;
  --bg-sidebar: #f3f3f3;
  --bg-sidebar-header: #f3f3f3;
  --bg-editor: #ffffff;
  --bg-breadcrumbs: #ffffff;
  --bg-tab-active: #ffffff;
  --bg-tab-inactive: #ececec;
  --bg-tab-hover: #e0e0e0;
  --bg-panel: #f8f8f8;
  --bg-terminal: #ffffff;
  --bg-statusbar: #007acc;
  --bg-input: #ffffff;
  --bg-input-focus: #ffffff;
  --bg-hover: #e8e8e8;
  --bg-selected: #e4e6f1;
  --bg-selected-inactive: #e8e8e8;
  --bg-notification: #ffffff;
  --bg-touchbar: #ececec;

  --border-color: #e5e5e5;
  --border-subtle: #eaeaea;
  --border-input: #cecece;
  --border-focus: #0078d4;

  --text-main: #3b3b3b;
  --text-muted: #6e6e6e;
  --text-bright: #000000;
  --text-dim: #8c8c8c;

  --remote-bg: #007acc;
  --remote-fg: #ffffff;
}

/* Dark+ Theme */
body.theme-dark-plus {
  --bg-app: #1e1e1e;
  --bg-titlebar: #323233;
  --bg-activitybar: #333333;
  --bg-sidebar: #252526;
  --bg-sidebar-header: #252526;
  --bg-editor: #1e1e1e;
  --bg-breadcrumbs: #1e1e1e;
  --bg-tab-active: #1e1e1e;
  --bg-tab-inactive: #2d2d2d;
  --bg-tab-hover: #2b2d30;
  --bg-panel: #1e1e1e;
  --bg-terminal: #1e1e1e;
  --bg-statusbar: #007acc;
  --bg-input: #3c3c3c;
  --bg-hover: #2a2d2e;
  --bg-selected: #094771;
  --bg-touchbar: #2d2d2d;
  --border-color: #383838;
}

/* Monokai Theme */
body.theme-monokai {
  --bg-app: #1e1f1c;
  --bg-titlebar: #1e1f1c;
  --bg-activitybar: #1e1f1c;
  --bg-sidebar: #272822;
  --bg-sidebar-header: #272822;
  --bg-editor: #272822;
  --bg-breadcrumbs: #272822;
  --bg-tab-active: #272822;
  --bg-tab-inactive: #1e1f1c;
  --bg-tab-hover: #3e3d32;
  --bg-panel: #1e1f1c;
  --bg-terminal: #272822;
  --bg-statusbar: #75715e;
  --bg-input: #3e3d32;
  --bg-hover: #3e3d32;
  --bg-selected: #49483e;
  --bg-touchbar: #272822;
  --border-color: #3e3d32;
}

/* Dracula Theme */
body.theme-dracula {
  --bg-app: #21222c;
  --bg-titlebar: #21222c;
  --bg-activitybar: #21222c;
  --bg-sidebar: #282a36;
  --bg-sidebar-header: #282a36;
  --bg-editor: #282a36;
  --bg-breadcrumbs: #282a36;
  --bg-tab-active: #282a36;
  --bg-tab-inactive: #21222c;
  --bg-tab-hover: #44475a;
  --bg-panel: #21222c;
  --bg-terminal: #282a36;
  --bg-statusbar: #6272a4;
  --bg-input: #44475a;
  --bg-hover: #44475a;
  --bg-selected: #44475a;
  --bg-touchbar: #282a36;
  --border-color: #44475a;
}

/* High Contrast Theme */
body.theme-high-contrast {
  --bg-app: #000000;
  --bg-titlebar: #000000;
  --bg-activitybar: #000000;
  --bg-sidebar: #000000;
  --bg-sidebar-header: #000000;
  --bg-editor: #000000;
  --bg-breadcrumbs: #000000;
  --bg-tab-active: #000000;
  --bg-tab-inactive: #000000;
  --bg-panel: #000000;
  --bg-terminal: #000000;
  --bg-statusbar: #000000;
  --bg-touchbar: #000000;
  --border-color: #6fc3df;
  --border-subtle: #6fc3df;
  --accent-color: #f38518;
  --text-main: #ffffff;
  --text-bright: #ffffff;
}

/* ==========================================================================
   Base Reset
   ========================================================================== */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  user-select: none;
  -webkit-user-select: none;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

html, body {
  width: 100%;
  height: 100%;
  overflow: hidden;
  background-color: var(--bg-app);
  color: var(--text-main);
  font-family: var(--font-ui);
  font-size: 13px;
  line-height: 1.4;
}

.mobile-view-switch {
  display: none;
}

#btn-mobile-keyboard-toggle {
  display: none;
}

#app {
  display: flex;
  flex-direction: column;
  width: 100vw;
  height: 100vh;
  height: 100dvh;
  overflow: hidden;
  position: relative;
}

/* ==========================================================================
   Title Bar
   ========================================================================== */
.titlebar {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  height: var(--titlebar-height);
  background-color: var(--bg-titlebar);
  border-bottom: 1px solid var(--border-color);
  padding: 0 10px;
  font-size: 12px;
  flex-shrink: 0;
  z-index: 30;
}

.titlebar-left, .titlebar-right {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.nav-arrow-btn, .titlebar-action-btn {
  background: none;
  border: none;
  color: var(--text-muted);
  cursor: pointer;
  padding: 4px 6px;
  border-radius: 4px;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  transition: color 0.15s, background-color 0.15s;
}

.nav-arrow-btn:hover, .titlebar-action-btn:hover {
  background-color: var(--bg-hover);
  color: var(--text-bright);
}

.titlebar-action-btn.active {
  color: var(--text-bright);
}
.nav-arrow-btn i, .titlebar-action-btn i {
  font-size: 14px;
}

.titlebar-center {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  border-radius: 6px;
  padding: 3px 10px;
  width: 440px;
  max-width: 45%;
  height: 25px;
  color: var(--text-main);
  cursor: pointer;
  transition: border-color 0.15s, background-color 0.15s;
}

.titlebar-center:hover {
  border-color: var(--border-focus);
  background-color: var(--bg-input-focus);
}

.titlebar-center-text {
  font-size: 12px;
  color: var(--text-main);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.titlebar-center-actions {
  display: flex;
  flex-wrap: wrap;
  color: var(--text-muted);
}

/* ==========================================================================
   Main Container
   ========================================================================== */
.main-container {
  display: flex;
  flex: 1;
  overflow: hidden;
  position: relative;
}

/* ==========================================================================
   Activity Bar
   ========================================================================== */
.activitybar {
  width: var(--activitybar-width);
  background-color: var(--bg-activitybar);
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  border-right: 1px solid var(--border-color);
  flex-shrink: 0;
  z-index: 25;
}

.activitybar-top, .activitybar-bottom {
  display: flex;
  flex-direction: column;
}

.activity-item {
  width: var(--activitybar-width);
  height: 48px;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  color: rgba(203, 213, 225, 0.55);
  cursor: pointer;
  position: relative;
  transition: color 0.15s, background-color 0.15s;
}

.activity-item i {
  font-size: 24px;
  -webkit-text-stroke: 0.55px currentColor;
  filter: drop-shadow(0 1px 2px rgba(0, 0, 0, 0.35));
  transition: transform 0.15s, -webkit-text-stroke 0.15s;
}

.activity-item:hover {
  color: #f8fafc;
  background-color: var(--bg-hover);
}

.activity-item:hover i {
  -webkit-text-stroke: 0.75px currentColor;
}

.activity-item.active {
  color: #f8fafc;
}

.activity-item.active i {
  -webkit-text-stroke: 0.75px currentColor;
}

.activity-item.active::before {
  content: "";
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 2.5px;
  background-color: var(--text-bright);
}

.badge.git-badge {
  position: absolute;
  top: 8px;
  right: 6px;
  background-color: #0078d4;
  color: #ffffff;
  font-size: 10px;
  font-weight: 700;
  border-radius: 10px;
  padding: 1px 5px;
  min-width: 14px;
  text-align: center;
  line-height: 12px;
}

/* ==========================================================================
   Primary Sidebar
   ========================================================================== */
.sidebar {
  width: var(--sidebar-width);
  min-width: 180px;
  max-width: 550px;
  background-color: var(--bg-sidebar);
  border-right: 1px solid var(--border-color);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  overflow: hidden;
  z-index: 20;
}

.sidebar-panel {
  display: none;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

.sidebar-panel.active {
  display: flex;
}

.sidebar-header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  padding: 4px 12px 3px 12px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--text-muted);
  flex-shrink: 0;
  min-height: 26px;
}

.sidebar-title {
  text-transform: uppercase;
}

.sidebar-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 2px;
}

.action-btn {
  background: none;
  border: none;
  color: var(--text-muted);
  cursor: pointer;
  padding: 2px 4px;
  border-radius: 4px;
  display: inline-flex;
  flex-wrap: wrap;
  justify-content: center;
  font-size: 14px;
  transition: color 0.15s, background-color 0.15s;
}

.action-btn:hover {
  background-color: var(--bg-hover);
  color: var(--text-bright);
}

.sidebar-section-header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  padding: 3px 10px;
  font-size: 11px;
  font-weight: 700;
  color: var(--text-muted);
  cursor: pointer;
  min-height: 22px;
}

.section-title-wrap {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.section-chevron {
  font-size: 12px;
  transition: transform 0.15s;
}

.sidebar-content {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
}

#explorer-tree-container.drag-over {
  background-color: rgba(0, 120, 212, 0.15);
  border: 1px dashed var(--accent-color);
}

/* Codicon & Custom File Icons (Bold & High Visibility) */
.codicon {
  font-weight: 700;
  -webkit-font-smoothing: antialiased;
  display: inline-block;
  vertical-align: middle;
}

.node-icon {
  font-size: 15px;
  margin-right: 4px;
}

.codicon-folder, .codicon-folder-opened {
  color: #e5b567 !important; /* VS Code warm golden folder color */
}

/* File Tree Nodes */
.tree-node {
  display: flex;
  flex-wrap: wrap;
  padding: 2px 6px;
  cursor: pointer;
  font-size: 13px;
  white-space: nowrap;
  text-overflow: ellipsis;
  border-radius: 3px;
  gap: 4px;
}

.tree-node:hover {
  background-color: var(--bg-hover);
  color: var(--text-bright);
}

.tree-node.active {
  background-color: var(--bg-selected);
  color: var(--text-bright);
}

.tree-node .arrow {
  font-size: 12px;
  width: 14px;
  color: var(--text-muted);
}

.tree-node.collapsed .tree-children { display: none; }
.tree-children { width: 100%; }

.tree-node.collapsed .arrow {
}

.node-name {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* File Explorer Status Colors (Codespaces / VS Code style) */
.tree-node.git-U .node-name,
.tree-node.git-A .node-name {
  color: #73c991; /* Untracked / Staged uncommitted: bright green */
}

.tree-node.git-M .node-name {
  color: #e2c08d; /* Modified uncommitted: warm amber / orange */
}

.tree-node.git-D .node-name {
  color: #f14c4c; /* Deleted: red */
  text-decoration: line-through;
}

.tree-node.has-error .node-name {
  color: #f85149 !important; /* Syntax error: bright red */
  font-weight: 600;
}

.tree-node.has-warning .node-name {
  color: #cca700; /* Warning: amber */
}

.node-git-badge {
  font-size: 10px;
  font-weight: 700;
  margin-left: auto;
  padding: 0 4px;
  border-radius: 3px;
  line-height: 14px;
  display: inline-flex;
  flex-wrap: wrap;
}

.node-git-badge.status-U,
.node-git-badge.status-A {
  color: #73c991;
}

.node-git-badge.status-M {
  color: #e2c08d;
}

.node-git-badge.status-D {
  color: #f14c4c;
}

.node-error-badge {
  color: #f85149;
  font-size: 11px;
  font-weight: 700;
  margin-left: auto;
  display: inline-flex;
  flex-wrap: wrap;
  gap: 2px;
}

/* Custom File Icons (Original) */
.custom-file-icon {
  display: inline-flex;
  flex-wrap: wrap;
  justify-content: center;
  font-size: 11px;
  font-weight: 700;
  width: 16px;
  height: 16px;
  margin-right: 2px;
}

.icon-py { color: #3572A5; }
.icon-sh { color: #89e051; }
.icon-json { color: #cbcb41; }
.icon-md { color: #519aba; }
.icon-img { color: #a074c4; }
.icon-git { color: #f14e32; }
.icon-txt { color: #858585; }
.icon-zip { color: #e5bf00; }

/* Markdown Preview Syntax Highlighting Tokens */
.token-comment { color: #546e8a; font-style: italic; }
.token-string { color: #86efac; }
.token-number { color: #fbbf24; }
.token-keyword { color: #a78bfa; font-weight: 600; }
.token-type { color: #67e8f9; }
.token-function { color: #f9a8d4; }
.token-tag { color: #818cf8; font-weight: 600; }
.token-attr { color: #67e8f9; }

/* Collapsible Sections in Explorer */
.sidebar-collapsible-section {
  border-top: 1px solid var(--border-color);
}

.collapsible-header {
  display: flex;
  flex-wrap: wrap;
  padding: 3px 10px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  color: var(--text-muted);
  cursor: pointer;
  gap: 4px;
  min-height: 22px;
}

.collapsible-header:hover {
  color: var(--text-bright);
}

/* ==========================================================================
   Workbench Body (Tabs, Breadcrumbs, Monaco, Panel)
   ========================================================================== */
.workbench-body {
  display: flex;
  flex-direction: column;
  flex: 1;
  overflow: hidden;
  background-color: var(--bg-editor);
}

/* Tabs Bar */
.editor-header-bar {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  background-color: var(--bg-tab-inactive);
  height: 32px;
  overflow: hidden;
  border-bottom: 1px solid var(--border-color);
  flex-shrink: 0;
}

.tabs-bar {
  display: flex;
  flex: 1;
  overflow-x: auto;
  overflow-y: hidden;
  height: 100%;
  scrollbar-width: none;
}

.tabs-bar::-webkit-scrollbar {
  display: none;
}

.tab {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding: 0 10px;
  height: 100%;
  background-color: var(--bg-tab-inactive);
  border-right: 1px solid var(--border-color);
  color: var(--text-muted);
  cursor: pointer;
  font-size: 12px;
  white-space: nowrap;
  min-width: 90px;
  max-width: 200px;
  position: relative;
  transition: background-color 0.1s, color 0.1s;
}

.tab:hover {
  background-color: var(--bg-tab-hover);
  color: var(--text-bright);
}

.tab.active {
  background-color: var(--bg-tab-active);
  color: var(--text-bright);
}

.tab.active::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background-color: var(--accent-color);
}

/* Tab Status Colors */
.tab.git-U .tab-title,
.tab.git-A .tab-title {
  color: #73c991;
}

.tab.git-M .tab-title {
  color: #e2c08d;
}

.tab.has-error .tab-title {
  color: #f85149 !important;
}

.tab-title {
  overflow: hidden;
  text-overflow: ellipsis;
  flex: 1;
}

.tab-close {
  font-size: 14px;
  border-radius: 3px;
  padding: 2px;
  opacity: 0.7;
}

.tab-close:hover {
  background-color: var(--bg-hover);
  opacity: 1;
}

.tab-dirty-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background-color: var(--text-bright);
  display: none;
}

.tab.dirty .tab-dirty-dot {
  display: block;
}

.tab.dirty .tab-close {
  display: none;
}

.tab.dirty:hover .tab-dirty-dot {
  display: none;
}

.tab.dirty:hover .tab-close {
  display: block;
}

.tabs-actions {
  display: flex;
  flex-wrap: wrap;
  padding: 0 6px;
  gap: 2px;
}

/* Breadcrumbs Bar */
.breadcrumbs-bar {
  display: flex;
  flex-wrap: wrap;
  height: 22px;
  background-color: var(--bg-breadcrumbs);
  padding: 0 10px;
  font-size: 11px;
  color: var(--text-muted);
  border-bottom: 1px solid var(--border-subtle);
  flex-shrink: 0;
}

.breadcrumb-item {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

/* Editor Container */
.editor-container {
  flex: 1;
  position: relative;
  overflow: hidden;
  background-color: var(--bg-editor);
}

#monaco-editor, #monaco-diff-editor {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
}

/* Media Preview Container */
#media-preview-container {
  width: 100%;
  height: 100%;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  background-color: var(--bg-editor);
}

.media-preview-content {
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  gap: 12px;
  max-width: 90%;
  max-height: 90%;
}

.media-preview-content img {
  max-width: 100%;
  max-height: 70vh;
  object-fit: contain;
  border-radius: 4px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.4);
}

.media-preview-info {
  font-size: 12px;
  color: var(--text-muted);
}

/* Markdown & HTML Preview Containers */
#markdown-preview-container,
#html-preview-container {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  background-color: var(--bg-editor);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  z-index: 10;
}

.preview-header-bar {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  height: 28px;
  padding: 2px 10px;
  background-color: var(--bg-tab-inactive);
  border-bottom: 1px solid var(--border-color);
  font-size: 11px;
  color: var(--text-muted);
  flex-shrink: 0;
}

.preview-title {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  font-weight: 600;
  color: var(--text-bright);
}

.preview-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.markdown-preview-scroll {
  flex: 1;
  overflow-y: auto;
  padding: 20px 28px;
  background-color: var(--bg-editor);
}

.html-preview-frame {
  flex: 1;
  width: 100%;
  height: 100%;
  border: none;
  background-color: #ffffff;
}

/* GitHub Flavored Markdown Body */
.markdown-body {
  max-width: 880px;
  margin: 0 auto;
  color: var(--text-bright);
  font-family: var(--font-ui);
  line-height: 1.6;
  font-size: 13.5px;
  user-select: text;
  -webkit-user-select: text;
}

.markdown-body h1, .markdown-body h2, .markdown-body h3, .markdown-body h4, .markdown-body h5, .markdown-body h6 {
  margin-top: 20px;
  margin-bottom: 10px;
  font-weight: 600;
  line-height: 1.25;
  color: var(--text-bright);
}

.markdown-body h1 { font-size: 1.8em; padding-bottom: 0.3em; border-bottom: 1px solid var(--border-color); }
.markdown-body h2 { font-size: 1.4em; padding-bottom: 0.3em; border-bottom: 1px solid var(--border-color); }
.markdown-body h3 { font-size: 1.2em; }
.markdown-body h4 { font-size: 1em; }

.markdown-body p, .markdown-body blockquote, .markdown-body ul, .markdown-body ol {
  margin-top: 0;
  margin-bottom: 14px;
}

.markdown-body hr {
  height: 1px;
  padding: 0;
  margin: 20px 0;
  background-color: var(--border-color);
  border: 0;
}

.markdown-body blockquote {
  padding: 0 1em;
  color: var(--text-muted);
  border-left: 0.25em solid var(--border-focus);
}

.markdown-body code {
  padding: 0.2em 0.4em;
  margin: 0;
  font-size: 85%;
  background-color: var(--bg-input);
  border-radius: 4px;
  font-family: var(--font-code);
}

.markdown-body .md-code-block {
  margin-bottom: 14px;
  border-radius: 6px;
  overflow: hidden;
  border: 1px solid var(--border-input);
  background-color: var(--bg-app);
}

.markdown-body .md-code-lang {
  background-color: var(--bg-input);
  padding: 4px 10px;
  font-size: 11px;
  color: var(--text-muted);
  font-family: var(--font-code);
  text-transform: uppercase;
  border-bottom: 1px solid var(--border-color);
}

.markdown-body pre {
  padding: 12px 14px;
  overflow: auto;
  font-size: 85%;
  line-height: 1.45;
  background-color: var(--bg-app);
  font-family: var(--font-code);
}

.markdown-body pre code {
  background-color: transparent;
  padding: 0;
}

.markdown-body ul, .markdown-body ol {
  padding-left: 2em;
}

.markdown-body li {
  margin-top: 0.25em;
}

.markdown-body .task-item {
  list-style-type: none;
  margin-left: -1.4em;
}

.markdown-body .md-table-wrap {
  overflow-x: auto;
  margin-bottom: 14px;
}

.markdown-body .md-table {
  border-collapse: collapse;
  width: 100%;
}

.markdown-body .md-table th, .markdown-body .md-table td {
  padding: 6px 12px;
  border: 1px solid var(--border-color);
}

.markdown-body .md-table tr:nth-child(2n) {
  background-color: var(--bg-hover);
}

.markdown-body a {
  color: var(--accent-blue);
  text-decoration: none;
}

.markdown-body a:hover {
  text-decoration: underline;
}

/* Watermark */
.empty-editor-watermark {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  justify-content: center;
  color: var(--text-muted);
  gap: 14px;
  z-index: 5;
}

.empty-editor-watermark i.codicon-vscode {
  font-size: 80px;
  opacity: 0.15;
}

.shortcuts-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  font-size: 12px;
}

.shortcut-item {
  display: flex;
  justify-content: space-between;
  gap: 24px;
}

kbd {
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  border-radius: 3px;
  padding: 2px 6px;
  font-family: var(--font-code);
  font-size: 11px;
}

/* Splitters */
.splitter-h {
  width: 4px;
  cursor: col-resize;
  background-color: transparent;
  transition: background-color 0.2s;
  z-index: 21;
}

.splitter-h:hover, .splitter-h.dragging {
  background-color: var(--accent-color);
}

.splitter-v {
  height: 4px;
  cursor: row-resize;
  background-color: transparent;
  transition: background-color 0.2s;
  z-index: 21;
}

.splitter-v:hover, .splitter-v.dragging {
  background-color: var(--accent-color);
}

/* Bottom Panel */
.panel {
  height: 240px;
  min-height: 60px;
  max-height: 80vh;
  background-color: var(--bg-panel);
  border-top: 1px solid var(--border-color);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
}

.sidebar-hidden { display: none !important; }
.panel.hidden {
  display: none !important;
}

.panel-header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  height: 28px;
  padding: 0 10px;
  border-bottom: 1px solid var(--border-color);
  flex-shrink: 0;
}

.panel-tabs {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.panel-tab {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  color: var(--text-muted);
  cursor: pointer;
  padding: 4px 2px;
  border-bottom: 2px solid transparent;
}

.panel-tab.active {
  color: var(--text-bright);
  border-bottom-color: var(--accent-color);
}

.tab-badge {
  background-color: var(--accent-color);
  color: #fff;
  border-radius: 10px;
  padding: 1px 5px;
  font-size: 9px;
}

.terminal-tab-group {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  overflow-x: auto;
  scrollbar-width: none;
}

.terminal-tab-item {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  padding: 2px 8px;
  background: var(--bg-input);
  border-radius: 4px;
  font-size: 11px;
  color: var(--text-muted);
  cursor: pointer;
}

.terminal-tab-item.active {
  background: var(--bg-selected);
  color: var(--text-bright);
}

.terminal-shell-badge {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  font-size: 11px;
  color: var(--text-muted);
  padding: 2px 6px;
  background: var(--bg-input);
  border-radius: 4px;
}

.panel-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.panel-actions-separator {
  width: 1px;
  height: 14px;
  background-color: var(--border-color);
  margin: 0 4px;
}

.panel-content {
  flex: 1;
  overflow: hidden;
  position: relative;
}

.terminal-container {
  width: 100%;
  height: 100%;
  padding: 4px 6px;
  background-color: var(--bg-terminal, #181818);
}

/* Status Bar */
.statusbar {
  height: var(--statusbar-height);
  background-color: var(--bg-statusbar);
  border-top: 1px solid var(--border-color);
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  padding: 0 8px;
  font-size: 11px;
  flex-shrink: 0;
  z-index: 30;
}

.statusbar-left, .statusbar-right {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.status-item {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  color: var(--text-muted);
  cursor: pointer;
  padding: 2px 4px;
  border-radius: 3px;
}

.status-item:hover {
  background-color: var(--bg-hover);
  color: var(--text-bright);
}

.status-remote-badge {
  background-color: var(--remote-bg);
  color: var(--remote-fg);
  padding: 2px 6px;
  font-weight: 600;
}

.status-remote-badge:hover {
  background-color: #0078d4;
  color: #fff;
}

/* ==========================================================================
   Mobile Touch Keypad Bar
   ========================================================================== */
.mobile-touch-bar {
  display: none;
  background-color: var(--bg-touchbar);
  border-top: 1px solid var(--border-color);
  padding: 4px 8px;
  overflow-x: auto;
  white-space: nowrap;
  gap: 6px;
  scrollbar-width: none;
  z-index: 19;
}

.mobile-touch-bar::-webkit-scrollbar {
  display: none;
}

.mobile-touch-bar.visible {
  display: flex;
}

.touch-key {
  background-color: var(--bg-input);
  border: 1px solid var(--border-input);
  color: var(--text-bright);
  padding: 3px 8px;
  min-width: 26px;
  height: 26px;
  border-radius: 4px;
  font-family: var(--font-code);
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  line-height: 1;
}

.touch-key .codicon {
  font-size: 13px;
}

.touch-key:active {
  background-color: var(--accent-color);
}

.touch-action-save {
  background-color: #0078d4;
  color: #ffffff;
}

.touch-action-run {
  background-color: #238636;
  color: #ffffff;
}

.touch-key-ctrl.ctrl-active {
  background-color: var(--accent-color);
  color: #fff;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.4) inset;
}

/* ==========================================================================
   Modals & Quick Open
   ========================================================================== */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.55);
  backdrop-filter: blur(2px);
  z-index: 200;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding-top: 40px;
}

.modal-overlay.hidden {
  display: none !important;
}

.quick-open-modal {
  width: 580px;
  max-width: calc(100vw - 32px);
  background: var(--bg-sidebar);
  border: 1px solid var(--border-input);
  border-radius: 6px;
  box-shadow: 0 16px 36px rgba(0, 0, 0, 0.7);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  animation: modalScale 0.15s ease-out;
}

@keyframes modalScale {
  from { opacity: 0; transform: scale(0.97); }
  to { opacity: 1; transform: scale(1); }
}

.quick-open-header {
  display: flex;
  flex-wrap: wrap;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  margin: 10px;
  border-radius: 4px;
  padding: 0 8px;
}

.quick-prefix {
  font-family: var(--font-code);
  color: var(--accent-color);
  font-weight: 700;
  font-size: 14px;
}

.quick-open-input {
  flex: 1;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  margin: 10px;
  padding: 8px 12px;
  color: var(--text-bright);
  border-radius: 4px;
  font-size: 13px;
  outline: none;
}

.quick-open-input.no-margin {
  margin: 0;
  border: none;
  background: transparent;
}

.quick-open-input:focus {
  border-color: var(--border-focus);
}

.quick-open-results {
  max-height: 360px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
}

.quick-item {
  padding: 8px 14px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  cursor: pointer;
  font-size: 12px;
}

.quick-item:hover, .quick-item.selected {
  background: var(--bg-selected);
  color: var(--text-bright);
}

/* ==========================================================================
   Context Menu
   ========================================================================== */
.context-menu {
  position: fixed;
  background: var(--bg-sidebar);
  border: 1px solid var(--border-input);
  border-radius: 4px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6);
  padding: 4px 0;
  z-index: 300;
  min-width: 170px;
}

.context-menu.hidden {
  display: none !important;
}

.context-item {
  padding: 6px 14px;
  cursor: pointer;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  font-size: 12px;
}

.context-item:hover {
  background: var(--accent-color);
  color: #ffffff;
}

.context-separator {
  height: 1px;
  background-color: var(--border-color);
  margin: 4px 0;
}

/* ==========================================================================
   Git & Search Panels
   ========================================================================== */
.git-panel, .search-panel {
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.git-commit-box {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.git-input {
  width: 100%;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  color: var(--text-bright);
  padding: 6px 8px;
  border-radius: 4px;
  resize: vertical;
  min-height: 50px;
  font-family: var(--font-ui);
  font-size: 12px;
}

.git-input:focus {
  outline: 1px solid var(--border-focus);
}

.git-btn-row {
  display: flex;
  gap: 6px;
}

.git-section-header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  color: var(--text-muted);
  margin-top: 6px;
}

.git-count-badge {
  background: var(--bg-input);
  padding: 1px 6px;
  border-radius: 10px;
  font-size: 10px;
}

.git-file-item {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  padding: 4px 6px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
}

.git-file-item:hover {
  background: var(--bg-hover);
}

.git-file-status {
  font-weight: 700;
  font-size: 11px;
}
.status-M { color: #e2c08d; }
.status-U { color: #73c991; }
.status-A { color: #73c991; }
.status-D { color: #f14c4c; }

.search-input-box {
  display: flex;
  flex-wrap: wrap;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  border-radius: 4px;
  padding: 2px 4px;
  gap: 4px;
}

.search-input-box input {
  flex: 1;
  background: none;
  border: none;
  color: var(--text-bright);
  padding: 4px 6px;
  font-size: 12px;
  outline: none;
}

.search-opt-btn {
  background: none;
  border: 1px solid transparent;
  color: var(--text-muted);
  font-family: var(--font-code);
  font-size: 11px;
  font-weight: 600;
  padding: 2px 5px;
  border-radius: 3px;
  cursor: pointer;
}

.search-opt-btn.active, .search-opt-btn:hover {
  background: var(--bg-selected);
  border-color: var(--border-focus);
  color: var(--text-bright);
}

.search-filter-box input {
  width: 100%;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  color: var(--text-bright);
  padding: 4px 6px;
  font-size: 11px;
  border-radius: 4px;
  outline: none;
}

.search-status-bar {
  font-size: 11px;
  color: var(--text-muted);
}

/* Toast Notifications */
.notifications-container {
  position: fixed;
  bottom: calc(var(--statusbar-height) + 10px);
  right: 14px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  z-index: 400;
  pointer-events: none;
}

.notification-toast {
  background: var(--bg-sidebar);
  border: 1px solid var(--border-input);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6);
  border-radius: 6px;
  padding: 10px 14px;
  color: var(--text-bright);
  font-size: 12px;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  min-width: 240px;
  max-width: 380px;
  pointer-events: auto;
  animation: toastIn 0.2s ease-out;
}

.notification-toast.fade-out {
  opacity: 0;
  transform: translateY(10px);
  transition: opacity 0.3s, transform 0.3s;
}

@keyframes toastIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

.toast-info i { color: #3794ff; }
.toast-success i { color: #23d18b; }
.toast-warning i { color: #f5f543; }
.toast-error i { color: #f14c4c; }

.toast-message {
  flex: 1;
}

.toast-close {
  cursor: pointer;
  opacity: 0.7;
}

.toast-close:hover {
  opacity: 1;
}

/* Generic Buttons */
.btn-primary {
  background-color: #0078d4;
  color: #ffffff;
  border: none;
  padding: 6px 12px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  display: inline-flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 6px;
}

.btn-primary:hover {
  background-color: #0098ff;
}

.btn-secondary {
  background-color: var(--bg-input);
  border: 1px solid var(--border-input);
  color: var(--text-bright);
  padding: 6px 12px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  display: inline-flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 6px;
}

.btn-secondary:hover {
  background-color: var(--bg-hover);
}

.placeholder-panel {
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.extension-item {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  background: var(--bg-input);
  padding: 10px;
  border-radius: 6px;
}

/* Settings Modal */
.settings-modal-box {
  width: 480px;
}

.settings-modal-header {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  padding: 12px 16px;
  border-bottom: 1px solid var(--border-color);
}

.theme-options-list {
  display: flex;
  flex-direction: column;
  padding: 4px 0;
  gap: 2px;
}

.theme-option {
  padding: 8px 12px;
  cursor: pointer;
  font-size: 12px;
  border-radius: 4px;
  transition: background-color 0.1s;
}

.theme-option:hover, .theme-option.active {
  background: var(--bg-selected);
  color: var(--text-bright);
}

/* ==========================================================================
   SUPER MOBILE RESPONSIVENESS
   ========================================================================== */
.sidebar-backdrop {
  display: none;
  position: fixed;
  top: var(--titlebar-height);
  left: 0;
  right: 0;
  bottom: var(--statusbar-height);
  background: rgba(0, 0, 0, 0.6);
  backdrop-filter: blur(2px);
  z-index: 18;
}

@media (max-width: 768px) {
  :root {
    --activitybar-width: 44px;
    --sidebar-width: 280px;
    --font-ui: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    --font-code: "JetBrains Mono", "Cascadia Code", "Fira Code", Consolas, monospace;
    --kb-offset: 0px;
  }

  html, body {
    font-size: 16px;
    font-weight: 600;
  }

  #btn-mobile-keyboard-toggle {
    display: flex;
  }

  .terminal-instance, .xterm, .xterm-screen {
    font-weight: 700 !important;
  }

  .titlebar-center {
    width: auto;
    max-width: 50%;
    padding: 3px 8px;
  }

  .sidebar {
    position: fixed;
    top: var(--titlebar-height);
    left: var(--activitybar-width);
    bottom: var(--statusbar-height);
    width: calc(100vw - var(--activitybar-width) - 20px);
    max-width: 320px;
    z-index: 22;
    transform: translateX(-120%);
    transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 4px 0 20px rgba(0, 0, 0, 0.5);
  }

  .sidebar.mobile-open {
    transform: translateX(0);
  }

  .sidebar-backdrop.mobile-open {
    display: block;
  }

  .splitter-h {
    display: none !important;
  }

  #status-indent, #status-encoding, #status-eol {
    display: none;
  }

  /* Mobile Full-Screen Swipeable Editor/Terminal */
  .workbench-body.mobile-swipe {
    position: relative;
    overflow: hidden;
  }
  .workbench-body.mobile-swipe .editor-container {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    transition: transform 0.28s cubic-bezier(0.4, 0, 0.2, 1);
    transform: translateX(0);
    z-index: 5;
    display: flex;
    flex-direction: column;
  }
  .workbench-body.mobile-swipe .splitter-v {
    display: none !important;
  }
  .workbench-body.mobile-swipe .panel {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    height: auto !important;
    max-height: none !important;
    transition: transform 0.28s cubic-bezier(0.4, 0, 0.2, 1);
    transform: translateX(100%);
    z-index: 6;
    border-top: none;
  }
  .workbench-body.mobile-swipe.show-terminal .editor-container {
    transform: translateX(-100%);
  }
  .workbench-body.mobile-swipe.show-terminal .panel {
    transform: translateX(0);
  }
  .workbench-body.mobile-swipe .panel.hidden {
    display: flex !important;
  }

  /* Touch bars: hidden by default, only shown via JS toggle (keyboard icon).
     Pinned to the bottom of the viewport, riding just above the on-screen
     keyboard via --kb-offset (set by JS from visualViewport). This makes
     both the editor and terminal bars behave identically regardless of
     where they sit in the DOM. */
  .mobile-touch-bar {
    display: none;
    flex-wrap: nowrap;
    flex-shrink: 0;
    overflow-x: auto;
    position: fixed;
    left: 0;
    right: 0;
    bottom: var(--kb-offset);
    z-index: 25;
    transition: bottom 0.15s ease-out;
  }
  #mobile-touch-bar-editor {
    left: var(--activitybar-width);
    bottom: calc(var(--statusbar-height) + var(--kb-offset));
  }
  .mobile-touch-bar.visible {
    display: flex;
  }
  /* Editor's own children (monaco, watermark, previews) flex to fill
     remaining space; the touch bar no longer takes flow space since it's
     fixed-positioned, so this just keeps the editor sized correctly. */
  .workbench-body.mobile-swipe .editor-container > *:not(.mobile-touch-bar) {
    flex: 1;
    min-height: 0;
  }
  .workbench-body.mobile-swipe .panel {
    display: flex;
    flex-direction: column;
  }
  .workbench-body.mobile-swipe .panel .panel-content {
    flex: 1;
    min-height: 0;
  }

  .mobile-view-switch {
    display: flex;
    position: fixed;
    bottom: calc(var(--statusbar-height) + 10px + var(--kb-offset));
    left: 50%;
    transform: translateX(-50%);
    z-index: 30;
    background-color: var(--bg-tab-inactive);
    border: 1px solid var(--border-color);
    border-radius: 20px;
    padding: 4px;
    gap: 2px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    transition: bottom 0.15s ease-out;
  }
  .mobile-view-switch-btn {
    padding: 6px 16px;
    font-size: 12px;
    font-weight: 600;
    border-radius: 16px;
    color: var(--text-muted);
    background: transparent;
    border: none;
    display: flex;
    align-items: center;
    gap: 5px;
  }
  .mobile-view-switch-btn.active {
    background-color: var(--accent-color);
    color: #fff;
  }
  .mobile-view-switch.keyboard-visible {
    display: none !important;
  }
}

@media (max-width: 480px) {
  :root {
    --titlebar-height: 38px;
    --statusbar-height: 24px;
    --activitybar-width: 40px;
  }

  .nav-arrow-btn {
    display: none;
  }

  #btn-hamburger {
    display: flex !important;
  }

  .titlebar-center {
    max-width: 45%;
  }

  #btn-toggle-aux-sidebar {
    display: none;
  }

  .tabs-actions {
    display: none;
  }

  .panel {
    height: 190px;
  }
}

/* File tree indent guides */
.tree-children {
  position: relative;
  padding-left: 12px;
}

.tree-children::before {
  content: "";
  position: absolute;
  left: 8px;
  top: 0;
  bottom: 0;
  width: 1px;
  background-color: var(--border-color, #404040);
}

.tree-children:hover::before {
  background-color: var(--accent-color, #569cd6);
}

/* Explorer header chevron connector - final */
.sidebar-section-header::after {
  content: "";
  position: absolute;
  left: 16px;
  top: 100%;
  width: 1px;
  height: 6px;
  background-color: var(--border-color);
  opacity: 0.8;
  z-index: 1;
}
CLAUDE_EOF_MARKER_9f3a
